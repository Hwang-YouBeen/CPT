package com.cau.cpt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CptApplication {

	public static void main(String[] args) {
		SpringApplication.run(CptApplication.class, args);
	}

}
