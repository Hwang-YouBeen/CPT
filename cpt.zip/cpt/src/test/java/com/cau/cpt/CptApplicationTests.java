package com.cau.cpt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CptApplicationTests {

	@Test
	void contextLoads() {
	}

}
